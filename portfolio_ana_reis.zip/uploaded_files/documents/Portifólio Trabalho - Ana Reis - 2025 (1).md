<!-- Page: 1 -->

## PORTFÓLIO

## 2025

## ANA REIS

MKT DIGITAL

BLOGDAANAREIS.COM.BR

<!-- Page: 2 -->

PALESTRANTE

Cursos | Motivacional

CRIADORA
DE CONTEÚDO

BLOGda AnaReis

<!-- Page: 3 -->

PROPOSTA PRESTAÇÃO DE SERVIÇOS
Comunicação, Design e Publicidade

Sobre Mim

Sou Ana Reis, comunicadora e especialista em marketing, com experiência em conteúdo, assessoria de imprensa e estratégias digitais. Fundadora do Portal de notícias Blog da Ana Reis e da Web Rádio FM Canaã, atuo com forte presença nas redes sociais, conectando marcas, serviços e pessoas por meio de uma comunicação humanizada e eficiente.

BLOGda AnaReis

<!-- Page: 4 -->

## Experiência de trabalho

## 2024

## CEO do portal de notícias - Blog da Ana Reis

• Matéria em primeira mão

• Notícias com credibilidade,

![image](https://static-us-img.skywork.ai/prod/nexus/1765132446/cropped_image_5_1765132446332064962.jpg)

## 2024

## Analista de MKT e Comunicação | Gestão

## 2018

• Comunicação Corporativa e Criação de Conteúdo (ebooks, blogs, design gráfico, Photoshop, Illustrator, Corel, Adobe Premiere);

• Pesquisa de Mercado e Assessoria de Eventos.

• Mídias Sociais: Gerenciamento, criação de comunidades e compra de mídia;

• Produção de Podcasts e Vídeos.

## Formação

## 2023 FaculdadePlay Educação Digital

MBA - Executivo em Gestão Estratégica de Publicidade e Propaganda.

2014 Faculdade FAMETRO Administração de Empresas

A oportunidade está nas mãos de quem sabe criar.

• - Ana Reis

![image](https://static-us-img.skywork.ai/prod/nexus/1765132446/cropped_image_19_1765132446426096595.jpg)

BLOGda AnaReis

<!-- Page: 5 -->

## PROJETO
REALIZADO

Roda de Conversa – Valor Humano da Pessoa com Deficiência no Mercado de Trabalho (25/04/2025)

Organizei a Roda de Conversa “Valor Humano da Pessoa com Deficiência no Mercado de Trabalho”, realizada na Câmara Municipal de Canaã dos Carajás. Desenvolvi o projeto, articulei parcerias e convidei representantes da Vale, do SINE, do Conselho da Pessoa com Deficiência e uma pessoa com deficiência para compor o diálogo.

A ação promoveu um debate profundo sobre inclusão, acessibilidade e oportunidades profissionais, fortalecendo o compromisso local com um mercado de trabalho mais justo, humano e diverso.

1ª Roda de conversa
Valor Humano da Pessoa com Deficiência
PALESTRANTE
CARLOS TESSAROLO
Gerente de RH da Vale/Serra Sul
TEMA: Programas e Ações de inclusão para Pessoa com Deficiência nas Operações Vale

TEMA: Programas e Ações de inclusão para Pessoas com Deficiência nas Operações Vale

©blegdaanareis Ⓡvalorthumanedapcd

![image](https://static-us-img.skywork.ai/prod/nexus/1765132447/cropped_image_7_1765132447122518266.jpg)

25 DE ABRIL SEXTA-FEIRA

![image](https://static-us-img.skywork.ai/prod/nexus/1765132447/cropped_image_9_1765132447120159249.jpg)

ÀS 18H30

![image](https://static-us-img.skywork.ai/prod/nexus/1765132447/cropped_image_11_1765132447121158986.jpg)

CÂMARA MUNICIPAL DE CANAÃ DOS CARAJÁS

AY, JOSE MARIA FRINO, QD 48 LT 17, RAIRO DEURO PARTO

## Habilidades pessoais

<!-- Portfólio 2025 -->

…

![image](https://static-us-img.skywork.ai/prod/nexus/1765132447/cropped_image_17_1765132447314666331.jpg)

Com uma sólida trajetória em marketing e comunicação, minhas habilidades combinam estratégia orientada por dados e criatividade, sempre com foco em resultados concretos. Abaixo, destaco minhas principais competências:

Designer gráfico

Marketing Digital

95%

Editor de vídeo

90%

Mídias Sociais

84%

Illustrador

96%

70%

Google AdWords

79%

<!-- Page: 6 -->

## Alcance
comprovado e
público qualificado

O Blog da Ana Reis conecta marcas e histórias com milhares de pessoas em toda a região Sudeste do Pará.

## PÚBLICO

## Gênero

75% do público é feminino, entre 21 e 61 anos — um perfil com poder de decisão de compra e alta influência em temas sociais e econômicos.

## Localização

Forte presença em Canaã dos Carajás, Parauapebas, Marabá e Tucuruí — cidades estratégicas com alto potencial de consumo e crescimento regional.

## Portal de notícias

![image](https://static-us-img.skywork.ai/prod/nexus/1765132447/cropped_image_8_1765132447520516351.jpg)

> www.blogdaanareis.com.br

## Web Rádio

![image](https://static-us-img.skywork.ai/prod/nexus/1765132447/cropped_image_11_1765132447531648112.jpg)

> www.fmcanaa.com.br

## Presença
Multiplataforma

• Instagram: 380 mil visualizações mensais, conteúdo dinâmico e alta interação.
• Portal de Notícias: Atualizações diárias, credibilidade jornalística e tráfego crescente.
• Web Rádio FM Canaã: Programas informativos e musicais, com alcance local e regional.

@Blogdaanareis

BLOGda AnaReis

<!-- Page: 7 -->

## Trabalhos Recente

## Notícias

## Rotary

Rotary Club de Canaã dos Carajás fortalece laços com a APAE com doação de cadeiras de rodas

![image](https://static-us-img.skywork.ai/prod/nexus/1765132449/cropped_image_4_1765132449817387763.jpg)

Na última terça-feira, 8 de outubro, o Rotary Club de Canaã dos Carajás reafirmou seu compromisso com a inclusão social ao doar duas codeiras de rodas para a APAE do município.

Essa iniciativa reforça a parceria entre as entidades...

informe publicitário
08/10/2024 07:30

![image](https://static-us-img.skywork.ai/prod/nexus/1765132450/cropped_image_8_1765132450216425028.jpg)

MATÉRIA INSTITUCIONAL

![image](https://static-us-img.skywork.ai/prod/nexus/1765132450/cropped_image_10_1765132450115555543.jpg)

VIDEO INSTITUCIONAL

![image](https://static-us-img.skywork.ai/prod/nexus/1765132450/cropped_image_12_1765132450113972186.jpg)

Isis Drumond
Jornalista

Delivery, carros elétricos, energia limpeira e mineração: veja onde a China pretende invernação: R$ 27 bilhões no Brasil

Canaã Gastronomia 2025 é um sucesso #blogdaanareis #festival #eufui

COBERTURA DE EVENTOS

1\(^{a}\) Roda de conversa
VHPCD

MATERIA
JORNALÍSTICA

CARLOS TESSAROLO
Gerente de RH da Vale/Serra Sul

TEMA: Programas e Ações de inclusão para Pessoas com Deficiência nas Operações Vale

25 DE ABRIL SEXTA-FEIRA
AS 18H30

CAMARA MUNICIPAL DE CANAÁ DOS CARAJAS

REALIZAÇÕES DE EVENTOS

![image](https://static-us-img.skywork.ai/prod/nexus/1765132450/cropped_image_24_1765132450022589708.jpg)

## NOTÍCIA

NÃO NEGOCIO MEUS PRINCÍPIOS, VERREADOR CLEIDO BRAZ MANDA MENSAGEM CLARA A CANAÃ DOS CARAJÁS

BbGia AvaReis VHPCD CONCEITO MATERIA NOTICIAS

![image](https://static-us-img.skywork.ai/prod/nexus/1765132450/cropped_image_28_1765132450318087267.jpg)

CRIAÇÃO DE LOGO

Identidade da marca

DESIGN DE MÍDIA SOCIAL

![image](https://static-us-img.skywork.ai/prod/nexus/1765132450/cropped_image_32_1765132450022576693.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1765132450/cropped_image_33_1765132450116387058.jpg)

> HOSPITAL YUTAKA TAKEDA

![image](https://static-us-img.skywork.ai/prod/nexus/1765132450/cropped_image_35_1765132450120888983.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1765132450/cropped_image_36_1765132450022505220.jpg)

## Municipios

![image](https://static-us-img.skywork.ai/prod/nexus/1765132450/cropped_image_38_1765132450118199588.jpg)

## -7 Canalos dos Carajás - PA

> CANAÃ DOS CARAJÁS: NOVOS NOMES ASSUMEM PASTAS ESTRATÉGICAS NA GESTÃO MUNICIPAL

![image](https://static-us-img.skywork.ai/prod/nexus/1765132450/cropped_image_41_1765132450119047556.jpg)

## -7 Paraupebas - PA

> Parauapebas fortalece parceria com o Governo do Para para impulsionar desenvolvimento econômico

![image](https://static-us-img.skywork.ai/prod/nexus/1765132449/cropped_image_44_1765132449911795673.jpg)

## Economia

<!-- HOSPITAL CINCO DE OUTUBRO -->

<!-- INSTAGRAM PESSOAL -->

<!-- SITE DE NOTÍCIAS -->

<!-- Page: 8 -->

![image](https://static-us-img.skywork.ai/prod/nexus/1765132450/cropped_image_0_1765132450217437681.jpg)

BENEFÍCIOS PARA
SUA EMPRESA

Soluções completas em comunicação, design e publicidade em um único lugar.

Estratégias personalizadas para alcançar melhores resultados.

Economia de tempo e recursos com uma gestão integrada.

Crescimento constante da marca online e offline.

## ANA REIS

Comunicação, Design e Publicidade

blogdaanareis@gmail.com

![image](https://static-us-img.skywork.ai/prod/nexus/1765132450/cropped_image_9_1765132450521031094.jpg)

(94) 9 9191-5135

![image](https://static-us-img.skywork.ai/prod/nexus/1765132450/cropped_image_11_1765132450510519781.jpg)

www.blogdaanareis.com.br

![image](https://static-us-img.skywork.ai/prod/nexus/1765132450/cropped_image_13_1765132450519516491.jpg)

@blogdaanareis

![image](https://static-us-img.skywork.ai/prod/nexus/1765132450/cropped_image_15_1765132450523809679.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1765132450/cropped_image_16_1765132450614917495.jpg)

> ANA REIS
CATEGORIA MARKETING DIGITAL

![image](https://static-us-img.skywork.ai/prod/nexus/1765132450/cropped_image_18_1765132450613108575.jpg)

@

<!-- Page: 9 -->

# CRIACÃO DE DESIGNS

VHPCD

Valor Humano da Pessoa com Deficiência

![image](https://static-us-img.skywork.ai/prod/nexus/1765132450/cropped_image_3_1765132450520546268.jpg)

![image](https://static-us-img.skywork.ai/prod/nexus/1765132450/cropped_image_4_1765132450523607162.jpg)

Vivasocial
AGENCYMKT

![image](https://static-us-img.skywork.ai/prod/nexus/1765132450/cropped_image_6_1765132450622713553.jpg)

Estamos elevando os padrões de saúde a um novo patamar de excelência!

VEJA MAIS

![image](https://static-us-img.skywork.ai/prod/nexus/1765132450/cropped_image_9_1765132450621082901.jpg)

> Dra. Cândice Vasconcelos

![image](https://static-us-img.skywork.ai/prod/nexus/1765132450/cropped_image_11_1765132450526304495.jpg)

TUTAKA TAKIDA PASA